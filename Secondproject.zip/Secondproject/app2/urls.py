from app2 import views

urlpatterns = [
    path('',views.home)